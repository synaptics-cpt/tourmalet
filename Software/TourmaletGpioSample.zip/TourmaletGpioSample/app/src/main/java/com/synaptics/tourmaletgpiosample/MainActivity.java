/*

Copyright 2017 Synaptics, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

*/

package com.synaptics.tourmaletgpiosample;

import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements Button.OnClickListener {

    Gpio input = new Gpio(902);
    Gpio output = new Gpio(903);

    PollGpiosTask pollGpiosTask = new PollGpiosTask();

    Button outputLow, outputHigh;
    RadioButton inputHigh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outputLow = (Button)findViewById(R.id.outputLow);
        outputLow.setOnClickListener(this);
        outputHigh = (Button)findViewById(R.id.outputHigh);
        outputHigh.setOnClickListener(this);

        inputHigh = (RadioButton)findViewById(R.id.inputHigh);

        input.open();
        input.setDirection(Gpio.DIRECTION_IN);

        output.open();
        output.setDirection(Gpio.DIRECTION_OUT);

        pollGpiosTask.execute(new Pair(input, inputHigh));
    }

    @Override
    public void onClick(View view) {
        if (view == outputLow) {
            output.setValue(0);
        } else if (view == outputHigh) {
            output.setValue(1);
        }
    }

    class PollGpiosTask extends AsyncTask<Pair<Gpio, RadioButton>, Pair<Integer, RadioButton>, Integer> {
        protected Integer doInBackground(Pair<Gpio,RadioButton>... params) {
            while (!isCancelled()) {
                for (Pair<Gpio, RadioButton> p : params)
                    publishProgress(new Pair(p.first.getValue(), p.second));

                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {

                }
            }
            return 0;
        }

        protected void onProgressUpdate(Pair<Integer, RadioButton>... progress) {
            for (Pair<Integer, RadioButton> p : progress)
                p.second.setChecked(p.first == 1);
        }
    }
}
