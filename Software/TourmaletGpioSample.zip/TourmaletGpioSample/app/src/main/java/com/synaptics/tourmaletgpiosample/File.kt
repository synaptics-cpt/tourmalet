/*

Copyright 2017 Synaptics, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

*/

package com.synaptics.tourmaletgpiosample

import eu.chainfire.libsuperuser.Shell
import kotlin.reflect.KProperty

abstract class File<T>(val path: String) {
    fun getStr(): String {
        val ret = Shell.SU.run("cat $path")
        val sb = StringBuilder()
        for (s in ret) {
            sb.append(s)
            sb.append(System.lineSeparator())
        }
        return sb.toString();
    }

    abstract fun get(): T;
    fun set(value: T) = Shell.SU.run("echo $value > $path")

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T = get();
    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: T) = set(value)
}

class StringFile(path: String): File<String>(path) {
    override fun get(): String = getStr()
}


class IntFile(path: String): File<Int>(path) {
    override fun get(): Int = Integer.valueOf(getStr().replace(System.lineSeparator(), ""))
}