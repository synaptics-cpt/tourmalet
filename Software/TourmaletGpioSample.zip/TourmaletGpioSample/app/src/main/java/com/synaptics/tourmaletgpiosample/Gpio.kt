/*

Copyright 2017 Synaptics, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

*/

package com.synaptics.tourmaletgpiosample

import eu.chainfire.libsuperuser.Shell
import kotlin.reflect.KProperty

class Gpio(val number: Int) {
    companion object {
        const val DIRECTION_IN = "in"
        const val DIRECTION_OUT = "out"
        const val DIRECTION_OUT_LOW = "low"
        const val DIRECTION_OUT_HIGH = "high"

        const val EDGE_NONE = "none"
        const val EDGE_RISING = "rising"
        const val EDGE_FALLING = "falling"
        const val EDGE_BOTH = "both"

        const val ACTIVE_LOW = 1
        const val ACTIVE_HIGH = 0
    }

    //init { open() }

    private val GPIO = "/sys/class/gpio"
    private val THIS = "$GPIO/gpio$number"

    fun open() { IntFile("$GPIO/export").set(number) }
    fun close() { IntFile("$GPIO/unexport").set(number) }

    var direction by StringFile("$THIS/direction")
    var value by IntFile("$THIS/value")
    var edge by StringFile("$THIS/edge")
    var active by IntFile("$THIS/active_low")
}